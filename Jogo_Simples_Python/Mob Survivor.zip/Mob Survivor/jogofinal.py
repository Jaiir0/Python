import pygame
import sys
from random import randint

pygame.init()

horizontal = 600
vertical = 700
tela = pygame.display.set_mode((horizontal, vertical))
pygame.display.set_caption("Mob Survivor")
clock = pygame.time.Clock()

# atributos do mob e do jogador
r = 6
vel_x = 3
vel_y = 3
player_vel = 4  # Velocidade do jogador

red = (203, 67, 53)

score = 0
fonte = pygame.font.SysFont('arial', 32, True, False)
fonte_game_over = pygame.font.SysFont('arial', 60, True, True)
fonte_score_final = pygame.font.SysFont('grabriola', 50, True, True)

# sprites
imagem_fundo = pygame.image.load('Sprites/grass.png').convert()
imagem_fundo = pygame.transform.scale(imagem_fundo, (horizontal, vertical))

# dicionário para armazenar os frames de animação para cada direção do player
player_frames = {
    'cima': [pygame.transform.scale(pygame.image.load(f'Sprites/player_cima{i}.png'), (10 * r, 10 * r)) for i in [1, 3]],
    'baixo': [pygame.transform.scale(pygame.image.load(f'Sprites/player_baixo{i}.png'), (10 * r, 10 * r)) for i in [1, 3]],
    'esquerda': [pygame.transform.scale(pygame.image.load(f'Sprites/player_esquerda ({i}).png'), (10 * r, 10 * r)) for i in [1, 3]],
    'direita': [pygame.transform.scale(pygame.image.load(f'Sprites/player_direita ({i}).png'), (10 * r, 10 * r)) for i in [1, 3]],
}

# dicionário para armazenar os frames de animação para cada direção dos mobs
mob_frames = {
    'cima': [pygame.transform.scale(pygame.image.load(f'Sprites/monster_0_{i}.png'), (6 * r, 6 * r)) for i in [7, 8]],
    'baixo': [pygame.transform.scale(pygame.image.load(f'Sprites/monster_0_{i}.png'), (6 * r, 6 * r)) for i in [1, 2]],
    'esquerda': [pygame.transform.scale(pygame.image.load(f'Sprites/monster_0_{i}.png'), (6 * r, 6 * r)) for i in [3, 4]],
    'direita': [pygame.transform.scale(pygame.image.load(f'Sprites/monster_0_{i}.png'), (6 * r, 6 * r)) for i in [5, 6]]
}

# carregar frames da moeda
moeda_frames = [pygame.transform.scale(pygame.image.load(f'Sprites/coin_0_{i}.png'), (7 * r, 7 * r)) for i in range(6)]

# temporizador de animação
animação_timer = 0
animation_interval = 350  # tempo em milissegundos para trocar entre os frames de todos os objetos
coin_animação_timer = 0
moeda_animacao_intervalo = 120  # tempo para a moeda (mais rápido)
moeda_frame_indice = 0

# reiniciar/começar o jogo
def reiniciar_jogo():
    global score, x_moeda, y_moeda, mobs_inimigos, game_over, moeda_frame_indice, player_x, player_y, player_direction, player_frame_index
    score = 0
    x_moeda = randint(10, 480)
    y_moeda = randint(10, 580)
    mobs_inimigos = [[randint(10, 490), randint(10, 590), vel_x, vel_y, 'direita', 0]]  # Adicionando frames e índice inicial
    game_over = False
    moeda_frame_indice = 0
    player_x = horizontal // 2  # posição no meio do jogador 
    player_y = vertical // 2
    player_direction = 'baixo'  # direção inicial
    player_frame_index = 0

reiniciar_jogo()

# loop principal do jogo
while True:
    clock.tick(60)
    tela.blit(imagem_fundo, (0, 0))
    
    # Atualizar e exibir pontuação
    mensagem = f'Score: {score}'
    texto_formatado = fonte.render(mensagem, False, (255,0,0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r and game_over:
                reiniciar_jogo()

    # atualizar o temporizador de animação da moeda
    coin_animação_timer += clock.get_time()
    if coin_animação_timer > moeda_animacao_intervalo:
        coin_animação_timer = 0
        moeda_frame_indice = (moeda_frame_indice + 1) % 6  # moeda possui 6 frames

    # atualizar o temporizador de animação dos mobs
    animação_timer += clock.get_time()
    if animação_timer > animation_interval:
        animação_timer = 0
        for mob in mobs_inimigos:
            # Alternar o índice do frame do mob
            mob[5] = (mob[5] + 1) % 2
        
        # índice do frame da moeda
        moeda_frame_indice = (moeda_frame_indice + 1) % len(moeda_frames)

    if not game_over:
        # movimentos do jogador com WASD
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            player_x -= player_vel
            player_direction = 'esquerda'
        if keys[pygame.K_d]:
            player_x += player_vel
            player_direction = 'direita'
        if keys[pygame.K_w]:
            player_y -= player_vel
            player_direction = 'cima'
        if keys[pygame.K_s]:
            player_y += player_vel
            player_direction = 'baixo'

        # manter o jogador dentro dos limites da tela
        player_x = max(0, min(horizontal - 4 * r, player_x))
        player_y = max(0, min(vertical - 4 * r, player_y))

        # atualizar o temporizador de animação do jogador
        animação_timer += clock.get_time()
        if animação_timer > animation_interval:
            animação_timer = 0
            player_frame_index = (player_frame_index + 1) % 2  # Alternar entre 2 frames

        # mover e desenhar todos os mobs inimigos
        for mob in mobs_inimigos:
            x, y, vel_x, vel_y, direction, frame_index = mob
            
            # movimentar o mob
            x += vel_x
            y += vel_y
            
            # Verificar colisão com as bordas da tela e inverter a direção
            if x - r < 0 or x + 4 * r > horizontal:
                vel_x = -vel_x
                direction = 'esquerda' if vel_x < 0 else 'direita'
            if y - r < 0 or y + 4 * r > vertical:
                vel_y = -vel_y
                direction = 'cima' if vel_y < 0 else 'baixo'

            # Atualizar a posição, frames e frame_index do mob na lista
            mob[0], mob[1], mob[2], mob[3], mob[4], mob[5] = x, y, vel_x, vel_y, direction, frame_index
            
            # Desenhar o mob usando o frame atual
            tela.blit(mob_frames[direction][frame_index], (x, y))

            # Verificar colisão entre o mob inimigo e o jogador
            player_rect = pygame.Rect(player_x, player_y, 4 * r, 4 * r)
            mob_rect = pygame.Rect(x, y, 4 * r, 4 * r)
            if player_rect.colliderect(mob_rect):
                game_over = True
                break

        if not game_over:
            # Desenhar o jogador usando o frame atual
            tela.blit(player_frames[player_direction][player_frame_index], (player_x, player_y))

            # Desenhar a moeda usando o frame atual
            tela.blit(moeda_frames[moeda_frame_indice], (x_moeda, y_moeda))

            # Verificar colisão do jogador com a moeda
            moeda_rect = pygame.Rect(x_moeda, y_moeda, 4 * r, 4 * r)
            if player_rect.colliderect(moeda_rect):
                x_moeda = randint(10, 480)
                y_moeda = randint(10, 580)
                score += 1
                
                # Adicionar um novo mob inimigo
                mobs_inimigos.append([randint(10, 490), randint(10, 590), vel_x, vel_y, 'direita', 0])

        # Exibir o texto da pontuação na tela
        tela.blit(texto_formatado, (455, 10))
    else:
        # Exibir a tela de Game Over
        mensagem_game_over = fonte_game_over.render("Game Over!", True, (150, 0, 0))
        tela.blit(mensagem_game_over, (horizontal // 5, vertical / 4.5))
        instrucoes_reiniciar = fonte.render("Pressione R para reiniciar", True, (150, 0, 0))
        tela.blit(instrucoes_reiniciar, (horizontal / 5.7, vertical / 2.8))
        score_final = fonte_score_final.render(f'Score: {score}', True, (0, 0, 0))
        tela.blit(score_final, (horizontal / 2.8, vertical / 1.8))

    # Atualizar a tela
    pygame.display.update()
