from PIL import Image
import os

# Caminho da imagem do sprite sheet
sprite_sheet_path = 'universal-lpc-sprite_male_01_walk-3frame.png'

# Carregar o sprite sheet
sprite_sheet = Image.open(sprite_sheet_path)

# Definir o tamanho de cada monstro (ajuste conforme necessário)
sprite_width = 50  # Largura de cada monstro
sprite_height = 58  # Altura de cada monstro

# Definir quantos monstros há por linha e coluna na sprite sheet
sprites_por_linha = sprite_sheet.width // sprite_width
sprites_por_coluna = sprite_sheet.height // sprite_height

# Diretório onde os sprites separados serão salvos
output_directory = 'Downloads/Spritesplayer/'

# Criar o diretório se ele não existir
os.makedirs(output_directory, exist_ok=True)

# Separar cada monstro
for linha in range(sprites_por_coluna):
    for coluna in range(sprites_por_linha):
        # Calcular a posição do sprite atual
        left = coluna * sprite_width
        upper = linha * sprite_height
        right = left + sprite_width
        lower = upper + sprite_height

        # Recortar o sprite atual
        sprite = sprite_sheet.crop((left, upper, right, lower))

        # Nomear o arquivo de saída
        sprite_name = f'coin_{linha}_{coluna}.png'
        sprite_path = os.path.join(output_directory, sprite_name)
        
        # Salvar o sprite como um arquivo separado
        sprite.save(sprite_path)

print("Sprites separados com sucesso!")
