fdin = open('C:\\Users\\39349\\Downloads/apache_logs.txt')
ips = []
maior_repetidor = 0
minutos = []
minuto_mais_presente = 0

for l in fdin:
    l = l.split()
    ips.append(l[0])
    minutos.append(l[3] [1:-3])

conexoes = []
minutos_diferentes = set(minutos)
ips_diferentes = set(ips)
fdin.close()

for min in minutos_diferentes:
    vezes_mais_conectadas = minutos.count(min)
    if vezes_mais_conectadas > minuto_mais_presente:
        minuto_mais_presente = vezes_mais_conectadas
        tempo = min
    conexoes.append((min,vezes_mais_conectadas))
conexoes.sort(key = lambda x: x[1], reverse=True)


for ip in ips:
    repetição = ips.count(ip)
    if repetição > maior_repetidor:
        maior_repetidor = repetição
        ip_mais_conectado = ip
    
   
print(f'o arquivo possui {len(ips_diferentes)} ips distintos ')
print(f'o ip que mais se conectou foi {ip} que se repetiu {maior_repetidor}')
print(f' o minuto mais presente foi {tempo} que se repetiu {minuto_mais_presente} vezes ')
print(f'os 10 momentos com mais conexões foram: {conexoes[0:10]}')
